# 📘 Digital School Diary – Homework Portal (MySQL Project)

## 📌 Overview
The **Digital School Diary** is a MySQL-based database system designed to serve as a backend solution for a school homework and activity portal. It helps schools manage students, parents, teachers, homework assignments, submissions, attendance, and notices—**all through SQL, with no frontend/backend development required**.

---

## 🧱 Database Schema Overview

The project includes the following **normalized tables**, with appropriate foreign keys, constraints, and sample data:

| Table Name        | Description                                                        |
|-------------------|--------------------------------------------------------------------|
| `classes`         | Stores class/section information                                   |
| `users`           | Centralized user table for students, teachers, admins, and parents |
| `subjects`        | Contains subjects assigned to specific classes and teachers        |
| `homework`        | Stores homework details with class, subject, and due dates         |
| `submissions`     | Tracks homework submissions per student                            |
| `attendance`      | Daily attendance log for each student                              |
| `notices`         | Stores general school announcements                                |
| `parent_student`  | Links parents with their respective children                       |

---

## ✅ Core Features Implemented

1. **Student Management**  
   Create and view students, link them to classes.

2. **Parent Management**  
   Store parent details and link with students using a relationship table.

3. **Teacher Management**  
   Manage teacher records and associate them with subjects.

4. **Class and Section Management**  
   Define classes and link students/teachers accordingly.

5. **Subject Management**  
   Map subjects to both classes and assigned teachers.

6. **Homework Assignment**  
   Teachers can assign homework with start and due dates.

7. **Homework Viewing**  
   Students (and parents indirectly) can view relevant homework.

8. **Submission Tracking**  
   Tracks homework submission status and date for each student.

---

## ✨ Bonus Features Included

- **Attendance Tracking**  
  Logs daily attendance of students.

- **Notices Table**  
  Acts like a digital notice board for important announcements.

- **Late Submission Detection**  
  Sample queries to identify late submissions using due dates.

---

## 🛠️ How to Use

### 🗂 Step 1: Setup Database
Run this script in MySQL 8.0 or later:
```sql
CREATE DATABASE digital_school_diary;
USE digital_school_diary;
```

### 📜 Step 2: Import SQL File
Use MySQL Workbench or CLI to execute the `digital_school_diary_magical.sql` file:
```bash
mysql -u root -p digital_school_diary < path_to/digital_school_diary_magical.sql
```

### 🧪 Step 3: Run Queries
You can run any of the queries from the `queries.sql` file or write your own:
```sql
SELECT * FROM users WHERE role = 'student';
```

---

## 📎 File Structure

```
📁 digital_school_diary/
├── schema.sql             # SQL commands to create all tables
├── data.sql               # Sample data insertion
├── queries.sql            # All test queries (CRUD + reporting)
├── README.md              # This file
```

---

## 🙋 Contact Details

**Project by**: *BOLLIKONDA SINDHU*  
**Email**: *sindhubollikonda80@gmail.com*  

---

## ✅ Evaluation Checklist

-  All 8 core features implemented
-  Database normalized with proper constraints
-  Sample data included
-  SQL queries for CRUD, reports, and tracking
-  Bonus features (attendance, notices, late submissions)
-  README.md with usage instructions

---

> ✨ **Enjoy exploring your magical school portal! May your queries always return rows!**
