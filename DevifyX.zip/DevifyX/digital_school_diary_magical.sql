-- 🏰 Digital School Diary: Enchanted SQL Script
-- ✨ Brought to you by the Grand Order of Data Sorcerers

-- 🧹 Purge old structures before summoning new spells
DROP TABLE IF EXISTS parent_student;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS submissions;
DROP TABLE IF EXISTS homework;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS classes;
DROP TABLE IF EXISTS notices;

-- 📚 Scroll of Classes - Where magical education begins
CREATE TABLE classes (
    class_id INT PRIMARY KEY,
    class_name VARCHAR(50) NOT NULL
);

-- 🧙‍♂️ Book of Beings - Registry of students, teachers, parents, and admins
CREATE TABLE users (
    user_id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'teacher', 'student', 'parent') NOT NULL,
    class_id INT,
    FOREIGN KEY (class_id) REFERENCES classes(class_id)
);

-- 📘 Codex of Subjects - Linking knowledge to mentors and classes
CREATE TABLE subjects (
    subject_id INT PRIMARY KEY,
    subject_name VARCHAR(100) NOT NULL,
    teacher_id INT,
    class_id INT,
    FOREIGN KEY (teacher_id) REFERENCES users(user_id),
    FOREIGN KEY (class_id) REFERENCES classes(class_id)
);

-- 🧾 Homework Ledger - Tasks and challenges for young wizards
CREATE TABLE homework (
    hw_id INT PRIMARY KEY,
    subject_id INT,
    teacher_id INT,
    class_id INT,
    assigned_date DATE NOT NULL,
    due_date DATE NOT NULL,
    description TEXT NOT NULL,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    FOREIGN KEY (teacher_id) REFERENCES users(user_id),
    FOREIGN KEY (class_id) REFERENCES classes(class_id)
);

-- 📬 Scroll Submissions - Record of completed magical tasks
CREATE TABLE submissions (
    submission_id INT PRIMARY KEY,
    hw_id INT,
    student_id INT,
    submitted_on DATE,
    status ENUM('submitted', 'late', 'pending'),
    FOREIGN KEY (hw_id) REFERENCES homework(hw_id),
    FOREIGN KEY (student_id) REFERENCES users(user_id)
);

-- 📅 Attendance Ledger - Presence detection crystal
CREATE TABLE attendance (
    attendance_id INT PRIMARY KEY,
    student_id INT,
    class_id INT,
    date DATE NOT NULL,
    status ENUM('present', 'absent') NOT NULL,
    FOREIGN KEY (student_id) REFERENCES users(user_id),
    FOREIGN KEY (class_id) REFERENCES classes(class_id)
);

-- 📣 School Notice Board - Proclamations and event scrolls
CREATE TABLE notices (
    notice_id INT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    content TEXT NOT NULL,
    posted_on DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 🪢 Family Bonds Table - Guardian connections to students
CREATE TABLE parent_student (
    parent_id INT,
    student_id INT,
    PRIMARY KEY (parent_id, student_id),
    FOREIGN KEY (parent_id) REFERENCES users(user_id),
    FOREIGN KEY (student_id) REFERENCES users(user_id)
);

-- 🪄 ENCHANTED INSERTS BEGIN HERE --

-- 🎓 Enroll Classes
INSERT INTO classes (class_id, class_name) VALUES 
(1, 'Class 1'), 
(2, 'Class 2');

-- 🧑‍🎓 Register Magical Beings (Users)
INSERT INTO users (user_id, name, email, password, role, class_id) VALUES
(1, 'Admin User', 'admin@school.com', 'admin123', 'admin', NULL),
(2, 'Teacher A', 'teacher1@school.com', 'teach123', 'teacher', NULL),
(3, 'Student One', 'student1@school.com', 'stud123', 'student', 1),
(4, 'Student Two', 'student2@school.com', 'stud234', 'student', 2),
(5, 'Parent A', 'parent1@school.com', 'parent123', 'parent', NULL);

-- 📖 Assign Subjects of Study
INSERT INTO subjects (subject_id, subject_name, teacher_id, class_id) VALUES
(1, 'Mathematics', 2, 1),
(2, 'Science', 2, 2);

-- 📜 Create Homework Assignments
INSERT INTO homework (hw_id, subject_id, teacher_id, class_id, assigned_date, due_date, description) VALUES
(1, 1, 2, 1, '2025-06-20', '2025-06-25', 'Complete Chapter 1'),
(2, 2, 2, 2, '2025-06-20', '2025-06-26', 'Write a report on plants');

-- 📤 Submit Homework Scrolls
INSERT INTO submissions (submission_id, hw_id, student_id, submitted_on, status) VALUES
(1, 1, 3, '2025-06-21', 'submitted'),
(2, 2, 4, NULL, 'pending');

-- 📅 Log Attendance in the Presence Crystal
INSERT INTO attendance (attendance_id, student_id, class_id, date, status) VALUES
(1, 3, 1, '2025-06-20', 'present'),
(2, 4, 2, '2025-06-20', 'absent');

-- 📯 Post Grandmaster Notices
INSERT INTO notices (notice_id, title, content) VALUES
(1, 'Welcome Back!', 'School reopens after summer vacation on July 1st.'),
(2, 'PTM Reminder', 'Parent-Teacher Meeting is scheduled on June 28th.');

-- 🧬 Forge Parent-Student Bonds
INSERT INTO parent_student (parent_id, student_id) VALUES (5, 3);

-- 🏁 The spell is complete. The Digital Diary is now alive! 🎉
