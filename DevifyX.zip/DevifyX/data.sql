-- 📘 DATA INSERTION SCRIPT for Digital School Diary

-- 🎓 Enroll Classes
INSERT INTO classes (class_id, class_name) VALUES 
(1, 'Class 1'), 
(2, 'Class 2');

-- 🧑‍🎓 Register Magical Beings (Users)
INSERT INTO users (user_id, name, email, password, role, class_id) VALUES
(1, 'Admin User', 'admin@school.com', 'admin123', 'admin', NULL),
(2, 'Teacher A', 'teacher1@school.com', 'teach123', 'teacher', NULL),
(3, 'Student One', 'student1@school.com', 'stud123', 'student', 1),
(4, 'Student Two', 'student2@school.com', 'stud234', 'student', 2),
(5, 'Parent A', 'parent1@school.com', 'parent123', 'parent', NULL);

-- 📖 Assign Subjects of Study
INSERT INTO subjects (subject_id, subject_name, teacher_id, class_id) VALUES
(1, 'Mathematics', 2, 1),
(2, 'Science', 2, 2);

-- 📜 Create Homework Assignments
INSERT INTO homework (hw_id, subject_id, teacher_id, class_id, assigned_date, due_date, description) VALUES
(1, 1, 2, 1, '2025-06-20', '2025-06-25', 'Complete Chapter 1'),
(2, 2, 2, 2, '2025-06-20', '2025-06-26', 'Write a report on plants');

-- 📤 Submit Homework Scrolls
INSERT INTO submissions (submission_id, hw_id, student_id, submitted_on, status) VALUES
(1, 1, 3, '2025-06-21', 'submitted'),
(2, 2, 4, NULL, 'pending');

-- 📅 Log Attendance in the Presence Crystal
INSERT INTO attendance (attendance_id, student_id, class_id, date, status) VALUES
(1, 3, 1, '2025-06-20', 'present'),
(2, 4, 2, '2025-06-20', 'absent');

-- 📯 Post Grandmaster Notices
INSERT INTO notices (notice_id, title, content) VALUES
(1, 'Welcome Back!', 'School reopens after summer vacation on July 1st.'),
(2, 'PTM Reminder', 'Parent-Teacher Meeting is scheduled on June 28th.');

-- 🧬 Forge Parent-Student Bonds
INSERT INTO parent_student (parent_id, student_id) VALUES (5, 3);
