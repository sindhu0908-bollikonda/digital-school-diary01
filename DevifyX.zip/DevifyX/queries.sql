-- 📊 Sample Queries for Digital School Diary

-- 🧒 View All Students
SELECT user_id, name, email, class_id
FROM users
WHERE role = 'student';

-- 👨‍👩‍👧‍👦 List All Parents and Their Children
SELECT 
    p.name AS parent_name, 
    s.name AS student_name
FROM parent_student ps
JOIN users p ON ps.parent_id = p.user_id
JOIN users s ON ps.student_id = s.user_id
WHERE p.role = 'parent';

-- 🧑‍🏫 List Teachers and What They Teach
SELECT 
    t.name AS teacher_name, 
    sub.subject_name, 
    c.class_name
FROM subjects sub
JOIN users t ON sub.teacher_id = t.user_id
JOIN classes c ON sub.class_id = c.class_id;

-- 📚 See All Subjects for a Class
SELECT 
    s.subject_name, 
    c.class_name
FROM subjects s
JOIN classes c ON s.class_id = c.class_id
WHERE c.class_name = 'Class 1';

-- 📝 List All Homework Assignments
SELECT 
    h.hw_id,
    h.description,
    h.assigned_date,
    h.due_date,
    s.subject_name,
    c.class_name
FROM homework h
JOIN subjects s ON h.subject_id = s.subject_id
JOIN classes c ON h.class_id = c.class_id;

-- 📅 See Homework Assigned to a Specific Student
SELECT 
    h.description, 
    h.assigned_date, 
    h.due_date, 
    sb.subject_name
FROM homework h
JOIN subjects sb ON h.subject_id = sb.subject_id
WHERE h.class_id = (
    SELECT class_id FROM users WHERE user_id = 3
);

-- ✅ Check Who Submitted Homework and When
SELECT 
    u.name AS student_name, 
    h.description AS homework_description, 
    s.submitted_on, 
    s.status
FROM submissions s
JOIN users u ON s.student_id = u.user_id
JOIN homework h ON s.hw_id = h.hw_id;

-- ⚠️ Find Late Submissions
SELECT 
    s.submission_id,
    u.name AS student,
    h.description AS homework,
    s.submitted_on,
    h.due_date,
    CASE 
        WHEN s.submitted_on > h.due_date THEN 'Late'
        ELSE 'On Time'
    END AS status
FROM submissions s
JOIN users u ON s.student_id = u.user_id
JOIN homework h ON s.hw_id = h.hw_id
WHERE s.submitted_on IS NOT NULL;

-- 🧾 List All Attendance Records
SELECT 
    u.name AS student_name,
    c.class_name,
    a.date,
    a.status
FROM attendance a
JOIN users u ON a.student_id = u.user_id
JOIN classes c ON a.class_id = c.class_id;

-- 📣 Show All Notices
SELECT 
    notice_id,
    title,
    content,
    posted_on
FROM notices;

-- 📊 Count Number of Students in Each Class
SELECT 
    c.class_name, 
    COUNT(u.user_id) AS total_students
FROM users u
JOIN classes c ON u.class_id = c.class_id
WHERE u.role = 'student'
GROUP BY c.class_name;

-- 📓 Find Pending Submissions Only
SELECT 
    u.name AS student,
    h.description,
    s.status
FROM submissions s
JOIN users u ON s.student_id = u.user_id
JOIN homework h ON s.hw_id = h.hw_id
WHERE s.status = 'pending';
